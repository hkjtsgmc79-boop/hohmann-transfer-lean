# Hohmann Transfer H1 — Chengyuan AI Lab

**Uncompiled Lean 4 candidate, not a verified release.**

Read `00_START_HERE.md` (Chinese), then `MATHEMATICAL_SPEC.md`.
The project constructs an outward, fixed-centre, coplanar circular-to-circular
Hohmann transfer with two ideal impulses. Its principal new analytic component
is the inverse Kepler clock, connecting eccentric anomaly to actual time.

Public entries:
- `HohmannTransfer.hohmann_transfer`
- `HohmannTransfer.exists_hohmann_transfer`

Twelve modules cover parameters, Euclidean geometry, a monotone bijective clock,
actual derivatives and Newton's equation, circular arcs, endpoint velocities,
impulses, coast invariants and exposed public statements. No optimality claim.

Run `python3 scripts/verify.py --help` for the local Lean handoff.
Independent Python smoke tests require SymPy, NumPy and SciPy:
`python3 scripts/check_math.py`. They do not certify Lean code.

`STATUS.json` and actual current source/log hashes determine the status. Generated
single-file exports duplicate modular code and are excluded from source-line totals.
