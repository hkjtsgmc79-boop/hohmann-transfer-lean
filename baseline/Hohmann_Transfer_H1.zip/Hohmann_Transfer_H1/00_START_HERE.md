# 霍曼转移 H1｜电脑端验证入口

**当前状态：SOURCE_CANDIDATE_NOT_COMPILED。尚无 Lean 编译通过记录。**

本项目与三体、量子隧穿、量子芝诺工程独立。不要修改旧项目、旧库缓存或已验证版本。
解压 `Hohmann_Transfer_H1.zip`，进入含 `lean-toolchain` 的工程根目录。
优先把 `01_LOCAL_CODEX_PROMPT.txt` 全文交给本地 Codex。

## 使用现有环境

要求 Lean 4.30.0，Mathlib checkout 为
`c5ea00351c28e24afc9f0f84379aa41082b1188f`，且没有已跟踪文件的修改。
沿用前面工程的配置并不意味着 H1 已经在该版本编译通过。

```bash
python3 scripts/verify.py \
  --lean /实际的/lean-4.30.0/bin/lean \
  --mathlib-root /实际的/mathlib4
```

上面的两个路径必须换为真实位置；也可设置 LEAN_BIN 和 MATHLIB_ROOT 后运行：

```bash
bash scripts/verify.sh
```

不要把 `core` 或 `full` 作为这个工程的额外参数；H1 的入口检查全部 12 模块。
脚本不安装软件，不执行 lake update，不下载依赖，不修改共享缓存。
缺少环境返回 BLOCKED（退出码2），编译或检查失败返回 FAIL（1），全通过才是 PASS（0）。

## 执行顺序

先检查 APIProbe；逐模块编译：
Parameters → Plane → Geometry → KeplerClock → Differentiation → Dynamics →
Circular → Endpoints → Impulses → Invariants → Transfer → PublicStatement。
再编译根入口、非退化例子、自动生成的单文件版本和16条公理检查。
每次使用新的 `.build-local/<run-id>` 目录，避免重复使用项目旧 olean。

主要难点预计在 KeplerClock 的序同构、逆函数求导 API，以及复坐标导数合成；
也可能要修复代数策略或补充引理。不能假定只运行一次就会通过。

## 禁止的“修复”

不能把 u=nt 当作偏近点角，不能将满足牛顿方程加入输入结构，不能改成 r₁=r₂，
不能删掉实际二阶导数或把 Δv 公式改为定义后自证，不能加入 sorry、axiom、unsafe。
PublicStatement 的公开命题签名已冻结；物理定义也必须保持含义。
若必须修改非命题性的定义实现，写明等价性证明与变更理由，不能改所证问题。

## 怎么回传

脚本会生成 `reports/Hohmann_Transfer_H1_return_<run-id>.zip`，包含当前源码和真实运行日志。
不管通过还是失败，都回传最后一次实际运行的包。
报告须包含 Lean 版本、Mathlib commit、首个失败模块、退出码及修复差异。
`reports/math-smoke.json` 仅是数学和数值预检，不是 Lean 证书。
