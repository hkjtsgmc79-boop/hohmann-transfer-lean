/- H1 uncompiled candidate. Generated from the modular sources; do not edit this copy. -/
import Mathlib

-- SOURCE MODULE: HohmannTransfer/Parameters.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Physical inputs and derived ellipse parameters
The input contains only μ, two radii, and physical inequalities.
No conservation law, orbit equation or optimality assertion is an input.
The first milestone treats outward, coplanar transfers, 0 < r₁ < r₂.
-/
structure Parameters where
  mu : ℝ
  r₁ : ℝ
  r₂ : ℝ
  mu_pos : 0 < mu
  r₁_pos : 0 < r₁
  outward : r₁ < r₂

namespace Parameters

def a (p : Parameters) : ℝ := (p.r₁ + p.r₂) / 2
def e (p : Parameters) : ℝ := (p.r₂ - p.r₁) / (p.r₁ + p.r₂)
def b (p : Parameters) : ℝ := Real.sqrt (p.r₁ * p.r₂)
def n (p : Parameters) : ℝ := Real.sqrt (p.mu / p.a ^ 3)
def transferTime (p : Parameters) : ℝ := Real.pi / p.n

lemma r₂_pos (p : Parameters) : 0 < p.r₂ := lt_trans p.r₁_pos p.outward
lemma sum_pos (p : Parameters) : 0 < p.r₁ + p.r₂ := add_pos p.r₁_pos p.r₂_pos
lemma a_pos (p : Parameters) : 0 < p.a := div_pos p.sum_pos (by norm_num)
lemma e_pos (p : Parameters) : 0 < p.e := div_pos (sub_pos.mpr p.outward) p.sum_pos
lemma e_lt_one (p : Parameters) : p.e < 1 := by
  unfold e
  apply (div_lt_one p.sum_pos).2
  linarith [p.r₁_pos]
lemma b_pos (p : Parameters) : 0 < p.b :=
  Real.sqrt_pos.2 (mul_pos p.r₁_pos p.r₂_pos)
lemma b_sq (p : Parameters) : p.b ^ 2 = p.r₁ * p.r₂ :=
  Real.sq_sqrt (le_of_lt (mul_pos p.r₁_pos p.r₂_pos))
lemma n_pos (p : Parameters) : 0 < p.n :=
  Real.sqrt_pos.2 (div_pos p.mu_pos (pow_pos p.a_pos 3))
lemma n_sq (p : Parameters) : p.n ^ 2 = p.mu / p.a ^ 3 :=
  Real.sq_sqrt (le_of_lt (div_pos p.mu_pos (pow_pos p.a_pos 3)))
lemma a_ne (p : Parameters) : p.a ≠ 0 := ne_of_gt p.a_pos
lemma n_ne (p : Parameters) : p.n ≠ 0 := ne_of_gt p.n_pos
lemma r₁_ne (p : Parameters) : p.r₁ ≠ 0 := ne_of_gt p.r₁_pos
lemma r₂_ne (p : Parameters) : p.r₂ ≠ 0 := ne_of_gt p.r₂_pos
lemma one_sub_e_pos (p : Parameters) : 0 < 1 - p.e := sub_pos.mpr p.e_lt_one
lemma one_add_e_pos (p : Parameters) : 0 < 1 + p.e := by linarith [p.e_pos]
lemma a_mul_one_sub_e (p : Parameters) : p.a * (1 - p.e) = p.r₁ := by
  unfold a e
  field_simp [ne_of_gt p.sum_pos]
  <;> ring
lemma a_mul_one_add_e (p : Parameters) : p.a * (1 + p.e) = p.r₂ := by
  unfold a e
  field_simp [ne_of_gt p.sum_pos]
  <;> ring
lemma b_sq_ellipse (p : Parameters) : p.b ^ 2 = p.a ^ 2 * (1 - p.e ^ 2) := by
  rw [p.b_sq]
  unfold a e
  field_simp [ne_of_gt p.sum_pos]
  <;> ring
lemma n_sq_mul_a_cube (p : Parameters) : p.n ^ 2 * p.a ^ 3 = p.mu := by
  rw [p.n_sq]
  field_simp [p.a_ne]
lemma transferTime_pos (p : Parameters) : 0 < p.transferTime :=
  div_pos Real.pi_pos p.n_pos
lemma transferTime_sq (p : Parameters) :
    p.transferTime ^ 2 * p.mu = Real.pi ^ 2 * p.a ^ 3 := by
  have hn := p.n_sq_mul_a_cube
  unfold transferTime
  field_simp [p.n_ne]
  nlinarith [congrArg (fun x : ℝ => Real.pi ^ 2 * x) hn]
lemma transferTime_eq (p : Parameters) :
    p.transferTime = Real.pi * Real.sqrt (p.a ^ 3 / p.mu) := by
  have hr := Real.sq_sqrt (le_of_lt (div_pos (pow_pos p.a_pos 3) p.mu_pos))
  have hroot := Real.sqrt_nonneg (p.a ^ 3 / p.mu)
  have ht := p.transferTime_sq
  have hμ := p.mu_pos
  have htpos := p.transferTime_pos
  have hproduct := mul_nonneg (le_of_lt Real.pi_pos) hroot
  have hs : p.transferTime ^ 2 =
      (Real.pi * Real.sqrt (p.a ^ 3 / p.mu)) ^ 2 := by
    rw [mul_pow, hr, ← mul_div_assoc]
    exact (eq_div_iff (ne_of_gt hμ)).2 ht
  nlinarith

end Parameters

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Plane.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # A Euclidean plane, represented by ℂ
Distances always use the Euclidean complex norm, never the sup norm of a
coordinate-product type. `pack_deriv` transports two actual real derivatives.
-/
def pack (x y : ℝ) : ℂ := ⟨x, y⟩
def cross (z w : ℂ) : ℝ := z.re * w.im - z.im * w.re
def sqSpeed (z : ℂ) : ℝ := z.re ^ 2 + z.im ^ 2

@[simp] lemma pack_re (x y : ℝ) : (pack x y).re = x := rfl
@[simp] lemma pack_im (x y : ℝ) : (pack x y).im = y := rfl
lemma sqSpeed_eq_norm_sq (z : ℂ) : sqSpeed z = ‖z‖ ^ 2 := by
  rw [← Complex.normSq_eq_norm_sq]
  simp [sqSpeed, Complex.normSq_apply, pow_two]
lemma norm_pack_sq (x y : ℝ) : ‖pack x y‖ ^ 2 = x ^ 2 + y ^ 2 := by
  simpa [sqSpeed] using (sqSpeed_eq_norm_sq (pack x y)).symm
lemma norm_pack_eq {x y r : ℝ} (hr : 0 ≤ r) (hs : x^2+y^2=r^2) :
    ‖pack x y‖ = r := by
  have hn := norm_nonneg (pack x y)
  have h := norm_pack_sq x y
  nlinarith
lemma norm_pack_vertical (y : ℝ) : ‖pack 0 y‖ = |y| := by
  apply norm_pack_eq (abs_nonneg y)
  simp
lemma pack_deriv {f g : ℝ → ℝ} {f' g' t : ℝ}
    (hf : HasDerivAt f f' t) (hg : HasDerivAt g g' t) :
    HasDerivAt (fun s => pack (f s) (g s)) (pack f' g') t := by
  have hd := hf.ofReal_comp.add (hg.ofReal_comp.mul_const Complex.I)
  convert hd using 1
  · funext s
    apply Complex.ext <;> simp [pack]
  · apply Complex.ext <;> simp [pack]
lemma pack_smul (c x y : ℝ) : c • pack x y = pack (c*x) (c*y) := by
  apply Complex.ext <;> simp [pack]
lemma pack_sub (x y u v : ℝ) : pack x y - pack u v = pack (x-u) (y-v) := rfl
lemma pack_neg (x y : ℝ) : -pack x y = pack (-x) (-y) := rfl

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Geometry.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Eccentric-anomaly geometry, before introducing physical time
The attracting centre is the focus at 0, not the centre of the ellipse.
-/
def D (p : Parameters) (u : ℝ) : ℝ := 1 - p.e * Real.cos u
def radial (p : Parameters) (u : ℝ) : ℝ := p.a * D p u
def ellipse (p : Parameters) (u : ℝ) : ℂ :=
  pack (p.a * (Real.cos u - p.e)) (p.b * Real.sin u)
def velocityAtAnomaly (p : Parameters) (u : ℝ) : ℂ :=
  pack (-p.a * p.n * Real.sin u / D p u)
    (p.b * p.n * Real.cos u / D p u)

lemma D_lower (p : Parameters) (u : ℝ) : 1 - p.e ≤ D p u := by
  unfold D
  nlinarith [Real.cos_le_one u, p.e_pos]
lemma D_upper (p : Parameters) (u : ℝ) : D p u ≤ 1 + p.e := by
  unfold D
  nlinarith [Real.neg_one_le_cos u, p.e_pos]
lemma D_pos (p : Parameters) (u : ℝ) : 0 < D p u :=
  lt_of_lt_of_le p.one_sub_e_pos (D_lower p u)
lemma D_ne (p : Parameters) (u : ℝ) : D p u ≠ 0 := ne_of_gt (D_pos p u)
lemma radial_pos (p : Parameters) (u : ℝ) : 0 < radial p u :=
  mul_pos p.a_pos (D_pos p u)
lemma ellipse_squared_radius (p : Parameters) (u : ℝ) :
    (ellipse p u).re ^ 2 + (ellipse p u).im ^ 2 = (radial p u)^2 := by
  have hb := p.b_sq_ellipse
  have ht := Real.sin_sq_add_cos_sq u
  simp only [ellipse, pack_re, pack_im, radial, D]
  calc
    (p.a * (Real.cos u - p.e)) ^ 2 + (p.b * Real.sin u) ^ 2 =
        p.a^2*(Real.cos u-p.e)^2 + p.b^2*Real.sin u^2 := by ring
    _ = (p.a * (1-p.e*Real.cos u))^2 := by
      rw [hb]
      nlinarith [congrArg (fun x : ℝ => p.a^2*(1-p.e^2)*x) ht]
lemma norm_ellipse (p : Parameters) (u : ℝ) : ‖ellipse p u‖ = radial p u := by
  apply norm_pack_eq (le_of_lt (radial_pos p u))
  exact ellipse_squared_radius p u
lemma radial_bounds (p : Parameters) (u : ℝ) :
    p.r₁ ≤ radial p u ∧ radial p u ≤ p.r₂ := by
  constructor
  · rw [← p.a_mul_one_sub_e]
    exact mul_le_mul_of_nonneg_left (D_lower p u) (le_of_lt p.a_pos)
  · rw [← p.a_mul_one_add_e]
    exact mul_le_mul_of_nonneg_left (D_upper p u) (le_of_lt p.a_pos)
lemma ellipse_ne_zero (p : Parameters) (u : ℝ) : ellipse p u ≠ 0 := by
  intro h
  have hn := norm_ellipse p u
  rw [h, norm_zero] at hn
  linarith [radial_pos p u]
@[simp] lemma D_zero (p : Parameters) : D p 0 = 1 - p.e := by simp [D]
@[simp] lemma D_pi (p : Parameters) : D p Real.pi = 1 + p.e := by simp [D]
@[simp] lemma ellipse_zero (p : Parameters) : ellipse p 0 = pack p.r₁ 0 := by
  apply Complex.ext <;> simp [ellipse]
  exact p.a_mul_one_sub_e
@[simp] lemma ellipse_pi (p : Parameters) : ellipse p Real.pi = pack (-p.r₂) 0 := by
  apply Complex.ext <;> simp [ellipse]
  nlinarith [p.a_mul_one_add_e]
lemma ellipse_periodic (p : Parameters) : Function.Periodic (ellipse p) (2*Real.pi) := by
  intro u
  apply Complex.ext <;> simp [ellipse, Real.cos_add_two_pi, Real.sin_add_two_pi]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/KeplerClock.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Constructing physical time, not postulating a time parametrization
The clock K(u)=(u-e*sin u)/n is a strictly increasing bijection ℝ → ℝ.
Its inverse is constructed from that proof. Neither inverse existence nor its
ODE is a hypothesis of the public theorem.
-/
def clock (p : Parameters) (u : ℝ) : ℝ := (u - p.e * Real.sin u) / p.n

lemma hasDerivAt_clock (p : Parameters) (u : ℝ) :
    HasDerivAt (clock p) (D p u / p.n) u := by
  simpa [clock, D] using
    ((hasDerivAt_id u).sub ((Real.hasDerivAt_sin u).const_mul p.e)).div_const p.n
lemma clock_continuous (p : Parameters) : Continuous (clock p) := by
  exact continuous_iff_continuousAt.2 (fun u => (hasDerivAt_clock p u).continuousAt)
lemma clock_strictMono (p : Parameters) : StrictMono (clock p) := by
  apply strictMono_of_hasDerivAt_pos (hasDerivAt_clock p)
  intro u
  exact div_pos (D_pos p u) p.n_pos
lemma clock_bounds (p : Parameters) (u : ℝ) :
    (u-p.e)/p.n ≤ clock p u ∧ clock p u ≤ (u+p.e)/p.n := by
  constructor
  · apply (div_le_div_iff_of_pos_right p.n_pos).2
    nlinarith [p.e_pos, Real.sin_le_one u]
  · apply (div_le_div_iff_of_pos_right p.n_pos).2
    nlinarith [p.e_pos, Real.neg_one_le_sin u]
lemma clock_surjective (p : Parameters) : Function.Surjective (clock p) := by
  intro t
  apply mem_range_of_exists_le_of_exists_ge (clock_continuous p)
  · refine ⟨p.n*t-p.e, ?_⟩
    calc
      clock p (p.n*t-p.e) ≤ (p.n*t-p.e+p.e)/p.n := (clock_bounds p _).2
      _ = t := by field_simp [p.n_ne]; ring
  · refine ⟨p.n*t+p.e, ?_⟩
    calc
      t = (p.n*t+p.e-p.e)/p.n := by field_simp [p.n_ne]; ring
      _ ≤ clock p (p.n*t+p.e) := (clock_bounds p _).1

/-- The inverse is the inverse of a proved order isomorphism. -/
def clockIso (p : Parameters) : ℝ ≃o ℝ where
  toEquiv := Equiv.ofBijective (clock p)
    ⟨(clock_strictMono p).injective, clock_surjective p⟩
  map_rel_iff' := by
    intro x y
    exact (clock_strictMono p).le_iff_le

def anomaly (p : Parameters) (t : ℝ) : ℝ := (clockIso p).symm t

lemma clock_anomaly (p : Parameters) (t : ℝ) : clock p (anomaly p t) = t := by
  exact (clockIso p).apply_symm_apply t
lemma anomaly_clock (p : Parameters) (u : ℝ) : anomaly p (clock p u) = u := by
  exact (clockIso p).symm_apply_apply u
lemma anomaly_continuous (p : Parameters) : Continuous (anomaly p) :=
  (clockIso p).symm.continuous
lemma anomaly_strictMono (p : Parameters) : StrictMono (anomaly p) :=
  (clockIso p).symm.strictMono
lemma hasDerivAt_anomaly (p : Parameters) (t : ℝ) :
    HasDerivAt (anomaly p) (p.n / D p (anomaly p t)) t := by
  have h := HasDerivAt.of_local_left_inverse
    (anomaly_continuous p).continuousAt
    (hasDerivAt_clock p (anomaly p t))
    (ne_of_gt (div_pos (D_pos p _) p.n_pos))
    (Filter.Eventually.of_forall (clock_anomaly p))
  simpa only [inv_div] using h
@[simp] lemma clock_zero (p : Parameters) : clock p 0 = 0 := by simp [clock]
@[simp] lemma clock_pi (p : Parameters) : clock p Real.pi = p.transferTime := by
  simp [clock, Parameters.transferTime]
@[simp] lemma anomaly_zero (p : Parameters) : anomaly p 0 = 0 := by
  simpa using anomaly_clock p 0
@[simp] lemma anomaly_transferTime (p : Parameters) :
    anomaly p p.transferTime = Real.pi := by
  simpa using anomaly_clock p Real.pi
lemma kepler_equation (p : Parameters) (t : ℝ) :
    anomaly p t - p.e * Real.sin (anomaly p t) = p.n*t := by
  have h := clock_anomaly p t
  unfold clock at h
  exact ((div_eq_iff p.n_ne).mp h).trans (mul_comm t p.n)
lemma anomaly_bounds (p : Parameters) {t : ℝ} (ht : t ∈ Set.Icc 0 p.transferTime) :
    anomaly p t ∈ Set.Icc 0 Real.pi := by
  constructor
  · simpa using (anomaly_strictMono p).monotone ht.1
  · simpa using (anomaly_strictMono p).monotone ht.2
lemma clock_add_two_pi (p : Parameters) (u : ℝ) :
    clock p (u+2*Real.pi) = clock p u + 2*p.transferTime := by
  simp only [clock, Real.sin_add_two_pi, Parameters.transferTime]
  ring
lemma anomaly_add_period (p : Parameters) (t : ℝ) :
    anomaly p (t+2*p.transferTime) = anomaly p t + 2*Real.pi := by
  apply (clock_strictMono p).injective
  rw [clock_anomaly, clock_add_two_pi, clock_anomaly]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Differentiation.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Actual first and second time derivatives
The eccentric anomaly is not linear in time except in the circular limit.
We differentiate the proved inverse Kepler clock, then apply the chain rule.
-/
def position (p : Parameters) (t : ℝ) : ℂ := ellipse p (anomaly p t)
def velocity (p : Parameters) (t : ℝ) : ℂ := velocityAtAnomaly p (anomaly p t)

lemma hasDerivAt_D (p : Parameters) (u : ℝ) :
    HasDerivAt (D p) (p.e*Real.sin u) u := by
  convert (hasDerivAt_const u (1:ℝ)).sub
    ((Real.hasDerivAt_cos u).const_mul p.e) using 1 <;> simp [D] <;> ring
lemma hasDerivAt_position (p : Parameters) (t : ℝ) :
    HasDerivAt (position p) (velocity p t) t := by
  have hu := hasDerivAt_anomaly p t
  have hx := (hu.cos.sub_const p.e).const_mul p.a
  have hy := hu.sin.const_mul p.b
  convert pack_deriv hx hy using 1
  · rfl
  · apply Complex.ext <;>
      simp [position, velocity, ellipse, velocityAtAnomaly, pack] <;> ring
lemma hasDerivAt_velocityAtAnomaly_x (p : Parameters) (u : ℝ) :
    HasDerivAt (fun s => (velocityAtAnomaly p s).re)
      (-p.a*p.n*(Real.cos u-p.e)/(D p u)^2) u := by
  have hnum := (Real.hasDerivAt_sin u).const_mul (-p.a*p.n)
  have h := hnum.div (hasDerivAt_D p u) (D_ne p u)
  convert h using 1
  · funext s; simp [velocityAtAnomaly, pack]
  · simp only [D]
    field_simp [D_ne p u]
    nlinarith [congrArg (fun x : ℝ => p.a*p.n*p.e*x)
      (Real.sin_sq_add_cos_sq u)]
lemma hasDerivAt_velocityAtAnomaly_y (p : Parameters) (u : ℝ) :
    HasDerivAt (fun s => (velocityAtAnomaly p s).im)
      (-p.b*p.n*Real.sin u/(D p u)^2) u := by
  have hnum := (Real.hasDerivAt_cos u).const_mul (p.b*p.n)
  have h := hnum.div (hasDerivAt_D p u) (D_ne p u)
  convert h using 1
  · funext s; simp [velocityAtAnomaly, pack]
  · dsimp [D]
    field_simp [D_ne p u]
    <;> ring
lemma hasDerivAt_velocity (p : Parameters) (t : ℝ) :
    HasDerivAt (velocity p)
      (-(p.n^2/(D p (anomaly p t))^3) • position p t) t := by
  have hx := (hasDerivAt_velocityAtAnomaly_x p (anomaly p t)).comp t
    (hasDerivAt_anomaly p t)
  have hy := (hasDerivAt_velocityAtAnomaly_y p (anomaly p t)).comp t
    (hasDerivAt_anomaly p t)
  convert pack_deriv hx hy using 1
  · rfl
  · apply Complex.ext <;>
      simp [position, ellipse, pack, smul_eq_mul] <;>
      field_simp [D_ne p (anomaly p t)] <;> ring
lemma deriv_position (p : Parameters) : deriv (position p) = velocity p := by
  funext t
  exact (hasDerivAt_position p t).deriv
lemma position_continuous (p : Parameters) : Continuous (position p) :=
  continuous_iff_continuousAt.2 (fun t => (hasDerivAt_position p t).continuousAt)
lemma velocity_continuous (p : Parameters) : Continuous (velocity p) :=
  continuous_iff_continuousAt.2 (fun t => (hasDerivAt_velocity p t).continuousAt)

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Dynamics.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Newtonian coast dynamics
Inverse-cube scalar times the displacement vector is the inverse-square force.
The norm denominator is proved nonzero along every point of the coast ellipse.
-/
def gravity (mu : ℝ) (q : ℂ) : ℂ := -(mu/‖q‖^3) • q

lemma norm_position (p : Parameters) (t : ℝ) :
    ‖position p t‖ = radial p (anomaly p t) := norm_ellipse p _
lemma position_bounds (p : Parameters) (t : ℝ) :
    p.r₁ ≤ ‖position p t‖ ∧ ‖position p t‖ ≤ p.r₂ := by
  rw [norm_position]
  exact radial_bounds p _
lemma norm_position_pos (p : Parameters) (t : ℝ) : 0 < ‖position p t‖ := by
  rw [norm_position]
  exact radial_pos p _
lemma position_ne_zero (p : Parameters) (t : ℝ) : position p t ≠ 0 :=
  ellipse_ne_zero p _
lemma acceleration_coefficient (p : Parameters) (u : ℝ) :
    p.n^2/(D p u)^3 = p.mu/(radial p u)^3 := by
  rw [p.n_sq]
  unfold radial
  field_simp [p.a_ne, D_ne p u]
lemma hasDerivAt_velocity_newton (p : Parameters) (t : ℝ) :
    HasDerivAt (velocity p) (gravity p.mu (position p t)) t := by
  convert hasDerivAt_velocity p t using 1
  rw [gravity, norm_position, acceleration_coefficient]
lemma second_deriv_position (p : Parameters) (t : ℝ) :
    deriv (deriv (position p)) t = -(p.mu/‖position p t‖^3) • position p t := by
  rw [deriv_position]
  exact (hasDerivAt_velocity_newton p t).deriv
lemma position_periodic (p : Parameters) :
    Function.Periodic (position p) (2*p.transferTime) := by
  intro t
  unfold position
  rw [anomaly_add_period]
  exact ellipse_periodic p _
lemma velocity_periodic (p : Parameters) :
    Function.Periodic (velocity p) (2*p.transferTime) := by
  intro t
  unfold velocity
  rw [anomaly_add_period]
  apply Complex.ext <;>
    simp [velocityAtAnomaly, D, Real.sin_add_two_pi, Real.cos_add_two_pi]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Circular.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Circular coast orbits before and after the impulses
Each arc has real time derivatives and satisfies the same gravity law.
-/
def circularRate (mu R : ℝ) : ℝ := Real.sqrt (mu/R^3)
def circularSpeed (mu R : ℝ) : ℝ := Real.sqrt (mu/R)
def circularPosition (mu R phase t : ℝ) : ℂ :=
  pack (R*Real.cos (circularRate mu R*t+phase))
    (R*Real.sin (circularRate mu R*t+phase))
def circularVelocity (mu R phase t : ℝ) : ℂ :=
  pack (-R*circularRate mu R*Real.sin (circularRate mu R*t+phase))
    (R*circularRate mu R*Real.cos (circularRate mu R*t+phase))

lemma circularRate_pos {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R) :
    0 < circularRate mu R := Real.sqrt_pos.2 (div_pos hm (pow_pos hR 3))
lemma circularRate_sq {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R) :
    circularRate mu R ^ 2 = mu/R^3 :=
  Real.sq_sqrt (le_of_lt (div_pos hm (pow_pos hR 3)))
lemma circularSpeed_pos {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R) :
    0 < circularSpeed mu R := Real.sqrt_pos.2 (div_pos hm hR)
lemma circularSpeed_sq {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R) :
    circularSpeed mu R ^ 2 = mu/R :=
  Real.sq_sqrt (le_of_lt (div_pos hm hR))
lemma circularSpeed_eq_rate {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R) :
    R*circularRate mu R = circularSpeed mu R := by
  have ha := circularRate_sq hm hR
  have hb := circularSpeed_sq hm hR
  have hpos := mul_pos hR (circularRate_pos hm hR)
  have hpos' := circularSpeed_pos hm hR
  have hs : (R*circularRate mu R)^2 = circularSpeed mu R^2 := by
    rw [mul_pow, ha, hb]
    field_simp [ne_of_gt hR]
    <;> ring
  nlinarith
lemma norm_circularPosition {mu R : ℝ} (hR : 0 < R) (phase t : ℝ) :
    ‖circularPosition mu R phase t‖ = R := by
  apply norm_pack_eq (le_of_lt hR)
  nlinarith [congrArg (fun x : ℝ => R^2*x)
    (Real.sin_sq_add_cos_sq (circularRate mu R*t+phase))]
lemma hasDerivAt_circularPosition (mu R phase t : ℝ) :
    HasDerivAt (circularPosition mu R phase) (circularVelocity mu R phase t) t := by
  have ha : HasDerivAt (fun s : ℝ => circularRate mu R*s+phase)
      (circularRate mu R) t := by
    simpa using ((hasDerivAt_id t).const_mul (circularRate mu R)).add_const phase
  convert pack_deriv (ha.cos.const_mul R) (ha.sin.const_mul R) using 1
  · rfl
  · apply Complex.ext <;> simp [circularVelocity, pack] <;> ring
lemma hasDerivAt_circularVelocity (mu R phase t : ℝ) :
    HasDerivAt (circularVelocity mu R phase)
      (-(circularRate mu R)^2 • circularPosition mu R phase t) t := by
  have ha : HasDerivAt (fun s : ℝ => circularRate mu R*s+phase)
      (circularRate mu R) t := by
    simpa using ((hasDerivAt_id t).const_mul (circularRate mu R)).add_const phase
  convert pack_deriv (ha.sin.const_mul (-R*circularRate mu R))
    (ha.cos.const_mul (R*circularRate mu R)) using 1
  · rfl
  · apply Complex.ext <;> simp [circularPosition, pack] <;> ring
lemma circular_newton {mu R : ℝ} (hm : 0 < mu) (hR : 0 < R)
    (phase t : ℝ) :
    deriv (deriv (circularPosition mu R phase)) t =
      -(mu/‖circularPosition mu R phase t‖^3) • circularPosition mu R phase t := by
  have hv : deriv (circularPosition mu R phase) = circularVelocity mu R phase := by
    funext s; exact (hasDerivAt_circularPosition mu R phase s).deriv
  rw [hv, (hasDerivAt_circularVelocity mu R phase t).deriv,
    norm_circularPosition hR, circularRate_sq hm hR]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Endpoints.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Endpoint geometry and speed derived from the actual time derivative -/
def periSpeed (p : Parameters) : ℝ := p.b*p.n/(1-p.e)
def apoSpeed (p : Parameters) : ℝ := p.b*p.n/(1+p.e)

lemma periSpeed_pos (p : Parameters) : 0 < periSpeed p :=
  div_pos (mul_pos p.b_pos p.n_pos) p.one_sub_e_pos
lemma apoSpeed_pos (p : Parameters) : 0 < apoSpeed p :=
  div_pos (mul_pos p.b_pos p.n_pos) p.one_add_e_pos
@[simp] lemma position_departure (p : Parameters) : position p 0 = pack p.r₁ 0 := by
  simp [position]
@[simp] lemma position_arrival (p : Parameters) :
    position p p.transferTime = pack (-p.r₂) 0 := by simp [position]
@[simp] lemma velocity_departure (p : Parameters) : velocity p 0 = pack 0 (periSpeed p) := by
  simp [velocity, velocityAtAnomaly, periSpeed]
@[simp] lemma velocity_arrival (p : Parameters) :
    velocity p p.transferTime = pack 0 (-apoSpeed p) := by
  apply Complex.ext <;> simp [velocity, velocityAtAnomaly, apoSpeed] <;> ring
lemma periSpeed_sq (p : Parameters) :
    periSpeed p ^ 2 = 2*p.mu*p.r₂/(p.r₁*(p.r₁+p.r₂)) := by
  have hper := p.a_mul_one_sub_e
  have haps := p.a_mul_one_add_e
  have hb := p.b_sq
  have hn := p.n_sq
  unfold periSpeed
  rw [div_pow, mul_pow, hb, hn]
  have he : 1-p.e = p.r₁/p.a := by
    apply (eq_div_iff p.a_ne).2
    nlinarith [hper]
  rw [he]
  unfold Parameters.a
  field_simp [p.r₁_ne, ne_of_gt p.sum_pos]
  <;> ring
lemma apoSpeed_sq (p : Parameters) :
    apoSpeed p ^ 2 = 2*p.mu*p.r₁/(p.r₂*(p.r₁+p.r₂)) := by
  have haps := p.a_mul_one_add_e
  unfold apoSpeed
  rw [div_pow, mul_pow, p.b_sq, p.n_sq]
  have he : 1+p.e = p.r₂/p.a := by
    apply (eq_div_iff p.a_ne).2
    nlinarith [haps]
  rw [he]
  unfold Parameters.a
  field_simp [p.r₂_ne, ne_of_gt p.sum_pos]
  <;> ring
lemma periSpeed_formula (p : Parameters) :
    periSpeed p = Real.sqrt (2*p.mu*p.r₂/(p.r₁*(p.r₁+p.r₂))) := by
  have hs := Real.sq_sqrt (le_of_lt
    (div_pos (mul_pos (mul_pos (by norm_num) p.mu_pos) p.r₂_pos) (mul_pos p.r₁_pos p.sum_pos)))
  have hn := Real.sqrt_nonneg (2*p.mu*p.r₂/(p.r₁*(p.r₁+p.r₂)))
  have hp := periSpeed_pos p
  have he := periSpeed_sq p
  nlinarith
lemma apoSpeed_formula (p : Parameters) :
    apoSpeed p = Real.sqrt (2*p.mu*p.r₁/(p.r₂*(p.r₁+p.r₂))) := by
  have hs := Real.sq_sqrt (le_of_lt
    (div_pos (mul_pos (mul_pos (by norm_num) p.mu_pos) p.r₁_pos) (mul_pos p.r₂_pos p.sum_pos)))
  have hn := Real.sqrt_nonneg (2*p.mu*p.r₁/(p.r₂*(p.r₁+p.r₂)))
  have hp := apoSpeed_pos p
  have he := apoSpeed_sq p
  nlinarith
lemma norm_velocity_departure (p : Parameters) : ‖velocity p 0‖ = periSpeed p := by
  rw [velocity_departure, norm_pack_vertical, abs_of_pos (periSpeed_pos p)]
lemma norm_velocity_arrival (p : Parameters) :
    ‖velocity p p.transferTime‖ = apoSpeed p := by
  rw [velocity_arrival, norm_pack_vertical, abs_neg, abs_of_pos (apoSpeed_pos p)]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Impulses.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Two velocity jumps, including vector directions
At the opposite end of the ellipse, prograde points toward negative y.
A positive second burn magnitude must NOT be implemented as a +y vector.
-/
def deltaV₁ (p : Parameters) : ℝ := periSpeed p - circularSpeed p.mu p.r₁
def deltaV₂ (p : Parameters) : ℝ := circularSpeed p.mu p.r₂ - apoSpeed p
def totalDeltaV (p : Parameters) : ℝ := deltaV₁ p + deltaV₂ p
def entryImpulse (p : Parameters) : ℂ :=
  velocity p 0 - pack 0 (circularSpeed p.mu p.r₁)
def exitImpulse (p : Parameters) : ℂ :=
  pack 0 (-circularSpeed p.mu p.r₂) - velocity p p.transferTime

lemma peri_excess_sq (p : Parameters) :
    periSpeed p ^ 2 - circularSpeed p.mu p.r₁ ^ 2 =
      p.mu*(p.r₂-p.r₁)/(p.r₁*(p.r₁+p.r₂)) := by
  rw [periSpeed_sq, circularSpeed_sq p.mu_pos p.r₁_pos]
  field_simp [p.r₁_ne, ne_of_gt p.sum_pos]
  <;> ring
lemma apo_deficit_sq (p : Parameters) :
    circularSpeed p.mu p.r₂ ^ 2 - apoSpeed p ^ 2 =
      p.mu*(p.r₂-p.r₁)/(p.r₂*(p.r₁+p.r₂)) := by
  rw [apoSpeed_sq, circularSpeed_sq p.mu_pos p.r₂_pos]
  field_simp [p.r₂_ne, ne_of_gt p.sum_pos]
  <;> ring
lemma deltaV₁_pos (p : Parameters) : 0 < deltaV₁ p := by
  have hs := peri_excess_sq p
  have hc := circularSpeed_pos p.mu_pos p.r₁_pos
  have hp := periSpeed_pos p
  have hd : 0 < p.mu*(p.r₂-p.r₁)/(p.r₁*(p.r₁+p.r₂)) :=
    div_pos (mul_pos p.mu_pos (sub_pos.mpr p.outward)) (mul_pos p.r₁_pos p.sum_pos)
  unfold deltaV₁
  nlinarith
lemma deltaV₂_pos (p : Parameters) : 0 < deltaV₂ p := by
  have hs := apo_deficit_sq p
  have hc := circularSpeed_pos p.mu_pos p.r₂_pos
  have hp := apoSpeed_pos p
  have hd : 0 < p.mu*(p.r₂-p.r₁)/(p.r₂*(p.r₁+p.r₂)) :=
    div_pos (mul_pos p.mu_pos (sub_pos.mpr p.outward)) (mul_pos p.r₂_pos p.sum_pos)
  unfold deltaV₂
  nlinarith
lemma totalDeltaV_pos (p : Parameters) : 0 < totalDeltaV p :=
  add_pos (deltaV₁_pos p) (deltaV₂_pos p)
lemma periSpeed_factorized (p : Parameters) :
    periSpeed p = circularSpeed p.mu p.r₁ * Real.sqrt (2*p.r₂/(p.r₁+p.r₂)) := by
  have hh : 0 < 2*p.r₂/(p.r₁+p.r₂) :=
    div_pos (mul_pos (by norm_num) p.r₂_pos) p.sum_pos
  have hr := Real.sq_sqrt (le_of_lt hh)
  have hc := circularSpeed_sq p.mu_pos p.r₁_pos
  have hp := periSpeed_pos p
  have hq := mul_nonneg (le_of_lt (circularSpeed_pos p.mu_pos p.r₁_pos))
    (Real.sqrt_nonneg (2*p.r₂/(p.r₁+p.r₂)))
  have hs : periSpeed p^2 =
      (circularSpeed p.mu p.r₁ * Real.sqrt (2*p.r₂/(p.r₁+p.r₂)))^2 := by
    rw [periSpeed_sq, mul_pow, hc, hr]
    field_simp [p.r₁_ne, ne_of_gt p.sum_pos]
    <;> ring
  nlinarith
lemma apoSpeed_factorized (p : Parameters) :
    apoSpeed p = circularSpeed p.mu p.r₂ * Real.sqrt (2*p.r₁/(p.r₁+p.r₂)) := by
  have hh : 0 < 2*p.r₁/(p.r₁+p.r₂) :=
    div_pos (mul_pos (by norm_num) p.r₁_pos) p.sum_pos
  have hr := Real.sq_sqrt (le_of_lt hh)
  have hc := circularSpeed_sq p.mu_pos p.r₂_pos
  have hp := apoSpeed_pos p
  have hq := mul_nonneg (le_of_lt (circularSpeed_pos p.mu_pos p.r₂_pos))
    (Real.sqrt_nonneg (2*p.r₁/(p.r₁+p.r₂)))
  have hs : apoSpeed p^2 =
      (circularSpeed p.mu p.r₂ * Real.sqrt (2*p.r₁/(p.r₁+p.r₂)))^2 := by
    rw [apoSpeed_sq, mul_pow, hc, hr]
    field_simp [p.r₂_ne, ne_of_gt p.sum_pos]
    <;> ring
  nlinarith
lemma deltaV₁_formula (p : Parameters) :
    deltaV₁ p = Real.sqrt (p.mu/p.r₁) *
      (Real.sqrt (2*p.r₂/(p.r₁+p.r₂))-1) := by
  rw [deltaV₁, periSpeed_factorized]
  unfold circularSpeed
  ring
lemma deltaV₂_formula (p : Parameters) :
    deltaV₂ p = Real.sqrt (p.mu/p.r₂) *
      (1-Real.sqrt (2*p.r₁/(p.r₁+p.r₂))) := by
  rw [deltaV₂, apoSpeed_factorized]
  unfold circularSpeed
  ring
lemma entryImpulse_eq (p : Parameters) : entryImpulse p = pack 0 (deltaV₁ p) := by
  rw [entryImpulse, velocity_departure]
  apply Complex.ext <;> simp [pack, deltaV₁]
lemma exitImpulse_eq (p : Parameters) : exitImpulse p = pack 0 (-deltaV₂ p) := by
  rw [exitImpulse, velocity_arrival]
  apply Complex.ext <;> simp [pack, deltaV₂] <;> ring
lemma entryImpulse_norm (p : Parameters) : ‖entryImpulse p‖ = deltaV₁ p := by
  rw [entryImpulse_eq, norm_pack_vertical, abs_of_pos (deltaV₁_pos p)]
lemma exitImpulse_norm (p : Parameters) : ‖exitImpulse p‖ = deltaV₂ p := by
  rw [exitImpulse_eq, norm_pack_vertical, abs_neg, abs_of_pos (deltaV₂_pos p)]
lemma totalDeltaV_eq_sum_norms (p : Parameters) :
    totalDeltaV p = ‖entryImpulse p‖ + ‖exitImpulse p‖ := by
  rw [entryImpulse_norm, exitImpulse_norm]
  rfl
lemma impulses_tangential (p : Parameters) :
    (position p 0).re * (entryImpulse p).re +
      (position p 0).im * (entryImpulse p).im = 0 ∧
    (position p p.transferTime).re * (exitImpulse p).re +
      (position p p.transferTime).im * (exitImpulse p).im = 0 := by
  simp [position_departure, position_arrival, entryImpulse_eq, exitImpulse_eq, pack]

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Invariants.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Coast specific energy, angular momentum, and the vis-viva identity
These are computed from the position and its actual derivative, not defined
as the desired constant. Specific energy means energy per unit spacecraft mass.
-/
def specificEnergy (mu : ℝ) (q v : ℂ) : ℝ := ‖v‖^2/2 - mu/‖q‖

lemma velocity_numerator (p : Parameters) (u : ℝ) :
    p.a^2*Real.sin u^2 + p.b^2*Real.cos u^2 =
      p.a^2 * D p u * (1+p.e*Real.cos u) := by
  rw [p.b_sq_ellipse]
  have hsin : Real.sin u^2 = 1-Real.cos u^2 := by
    nlinarith [Real.sin_sq_add_cos_sq u]
  rw [hsin]
  unfold D
  ring
lemma velocityAtAnomaly_norm_sq (p : Parameters) (u : ℝ) :
    ‖velocityAtAnomaly p u‖^2 =
      p.n^2*p.a^2*(1+p.e*Real.cos u)/D p u := by
  rw [← sqSpeed_eq_norm_sq]
  calc
    sqSpeed (velocityAtAnomaly p u) =
        p.n^2*(p.a^2*Real.sin u^2+p.b^2*Real.cos u^2)/(D p u)^2 := by
      unfold sqSpeed velocityAtAnomaly
      simp only [pack_re, pack_im]
      field_simp [D_ne p u]
      <;> ring
    _ = p.n^2*p.a^2*(1+p.e*Real.cos u)/D p u := by
      rw [velocity_numerator]
      field_simp [D_ne p u]
      <;> ring
lemma vis_viva_at_anomaly (p : Parameters) (u : ℝ) :
    ‖velocityAtAnomaly p u‖^2 = p.mu*(2/‖ellipse p u‖-1/p.a) := by
  rw [velocityAtAnomaly_norm_sq, norm_ellipse, p.n_sq]
  unfold radial
  field_simp [p.a_ne, D_ne p u]
  dsimp [D]
  ring
lemma vis_viva (p : Parameters) (t : ℝ) :
    ‖deriv (position p) t‖^2 = p.mu*(2/‖position p t‖-1/p.a) := by
  rw [deriv_position]
  exact vis_viva_at_anomaly p _
lemma coast_energy (p : Parameters) (t : ℝ) :
    specificEnergy p.mu (position p t) (deriv (position p) t) = -p.mu/(2*p.a) := by
  unfold specificEnergy
  rw [vis_viva]
  field_simp [p.a_ne, ne_of_gt (norm_position_pos p t)]
  <;> ring
lemma coast_energy_negative (p : Parameters) (t : ℝ) :
    specificEnergy p.mu (position p t) (deriv (position p) t) < 0 := by
  rw [coast_energy]
  exact div_neg_of_neg_of_pos (neg_neg_of_pos p.mu_pos) (mul_pos (by norm_num) p.a_pos)
lemma angular_momentum_at_anomaly (p : Parameters) (u : ℝ) :
    cross (ellipse p u) (velocityAtAnomaly p u) = p.a*p.b*p.n := by
  have hs : Real.sin u^2 = 1-Real.cos u^2 := by
    nlinarith [Real.sin_sq_add_cos_sq u]
  unfold cross ellipse velocityAtAnomaly
  simp only [pack_re, pack_im]
  field_simp [D_ne p u]
  dsimp [D]
  nlinarith [congrArg (fun x : ℝ => p.a*p.b*p.n*x) hs]
lemma coast_angular_momentum (p : Parameters) (t : ℝ) :
    cross (position p t) (deriv (position p) t) = p.a*p.b*p.n := by
  rw [deriv_position]
  exact angular_momentum_at_anomaly p _
lemma coast_angular_momentum_pos (p : Parameters) (t : ℝ) :
    0 < cross (position p t) (deriv (position p) t) := by
  rw [coast_angular_momentum]
  exact mul_pos (mul_pos p.a_pos p.b_pos) p.n_pos

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/Transfer.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Joining the three coast arcs with two instantaneous impulses
All three arcs are defined on ℝ for easy differentiation; a flight uses the
incoming arc before 0, transfer arc on [0,τ], and outgoing arc after τ.
At the impulses position values match and velocity is allowed to jump.
No classical unforced ODE is asserted at either instantaneous burn.
-/
def incoming (p : Parameters) (t : ℝ) : ℂ := circularPosition p.mu p.r₁ 0 t
def outgoingPhase (p : Parameters) : ℝ := Real.pi-circularRate p.mu p.r₂*p.transferTime
def outgoing (p : Parameters) (t : ℝ) : ℂ :=
  circularPosition p.mu p.r₂ (outgoingPhase p) t
def flight (p : Parameters) (t : ℝ) : ℂ :=
  if t < 0 then incoming p t else if t ≤ p.transferTime then position p t else outgoing p t

lemma incoming_deriv (p : Parameters) (t : ℝ) :
    deriv (incoming p) t = circularVelocity p.mu p.r₁ 0 t :=
  (hasDerivAt_circularPosition _ _ _ _).deriv
lemma outgoing_deriv (p : Parameters) (t : ℝ) :
    deriv (outgoing p) t = circularVelocity p.mu p.r₂ (outgoingPhase p) t :=
  (hasDerivAt_circularPosition _ _ _ _).deriv
lemma incoming_newton (p : Parameters) (t : ℝ) :
    deriv (deriv (incoming p)) t = -(p.mu/‖incoming p t‖^3) • incoming p t :=
  circular_newton p.mu_pos p.r₁_pos 0 t
lemma outgoing_newton (p : Parameters) (t : ℝ) :
    deriv (deriv (outgoing p)) t = -(p.mu/‖outgoing p t‖^3) • outgoing p t :=
  circular_newton p.mu_pos p.r₂_pos (outgoingPhase p) t
lemma incoming_radius (p : Parameters) (t : ℝ) : ‖incoming p t‖ = p.r₁ :=
  norm_circularPosition p.r₁_pos 0 t
lemma outgoing_radius (p : Parameters) (t : ℝ) : ‖outgoing p t‖ = p.r₂ :=
  norm_circularPosition p.r₂_pos (outgoingPhase p) t
@[simp] lemma incoming_zero (p : Parameters) : incoming p 0 = pack p.r₁ 0 := by
  simp [incoming, circularPosition, pack]
lemma outgoing_angle (p : Parameters) :
    circularRate p.mu p.r₂*p.transferTime + outgoingPhase p = Real.pi := by
  unfold outgoingPhase
  ring
@[simp] lemma outgoing_arrival (p : Parameters) :
    outgoing p p.transferTime = pack (-p.r₂) 0 := by
  simp [outgoing, circularPosition, outgoing_angle, pack]
lemma incoming_velocity_zero (p : Parameters) :
    deriv (incoming p) 0 = pack 0 (circularSpeed p.mu p.r₁) := by
  rw [incoming_deriv]
  simp [circularVelocity, circularSpeed_eq_rate p.mu_pos p.r₁_pos, pack]
lemma outgoing_velocity_arrival (p : Parameters) :
    deriv (outgoing p) p.transferTime = pack 0 (-circularSpeed p.mu p.r₂) := by
  rw [outgoing_deriv]
  apply Complex.ext <;>
    simp [circularVelocity, outgoing_angle, pack, circularSpeed_eq_rate p.mu_pos p.r₂_pos]
lemma junction_positions (p : Parameters) :
    incoming p 0 = position p 0 ∧
      position p p.transferTime = outgoing p p.transferTime := by simp
lemma junction_velocity_jumps (p : Parameters) :
    deriv (position p) 0 - deriv (incoming p) 0 = entryImpulse p ∧
    deriv (outgoing p) p.transferTime - deriv (position p) p.transferTime = exitImpulse p := by
  rw [deriv_position, incoming_velocity_zero, outgoing_velocity_arrival]
  exact ⟨rfl,rfl⟩
lemma flight_before (p : Parameters) {t : ℝ} (ht : t < 0) :
    flight p t = incoming p t := by simp [flight, ht]
lemma flight_transfer (p : Parameters) {t : ℝ} (ht : t ∈ Set.Icc 0 p.transferTime) :
    flight p t = position p t := by simp [flight, not_lt.mpr ht.1, ht.2]
lemma flight_after (p : Parameters) {t : ℝ} (ht : p.transferTime < t) :
    flight p t = outgoing p t := by
  have h : ¬t<0 := not_lt.mpr (le_of_lt (lt_trans p.transferTime_pos ht))
  simp [flight, h, not_le.mpr ht]
lemma apsidal_parameters_unique (p : Parameters) {A E : ℝ}
    (hA : 0 < A) (h₁ : A*(1-E)=p.r₁) (h₂ : A*(1+E)=p.r₂) :
    A = p.a ∧ E = p.e := by
  have ha : A = p.a := by unfold Parameters.a; nlinarith
  refine ⟨ha, ?_⟩
  unfold Parameters.e
  apply (eq_div_iff (ne_of_gt p.sum_pos)).2
  nlinarith

end HohmannTransfer

-- SOURCE MODULE: HohmannTransfer/PublicStatement.lean
/-
Copyright (c) 2026 Chengyuan AI Lab. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chengyuan AI Lab

H1 STATUS: uncompiled proof candidate; see STATUS.json.
-/

noncomputable section
namespace HohmannTransfer

/-! # Public theorem contract: outward Hohmann transfer
Fixed-centre, inverse-square, coplanar, circular-to-circular, two ideal impulses.
No claim of global fuel optimality, finite-thrust guidance, rendezvous with a
particular satellite, or existence for arbitrary initial velocities is made.
The public statements expose real derivatives and vector jump norms.
-/

theorem hohmann_transfer (p : Parameters) :
    0 < p.transferTime ∧
    (∀ t, deriv (deriv (position p)) t =
      -(p.mu/‖position p t‖^3) • position p t) ∧
    (∀ t, p.r₁ ≤ ‖position p t‖ ∧ ‖position p t‖ ≤ p.r₂) ∧
    position p 0 = pack p.r₁ 0 ∧
    position p p.transferTime = pack (-p.r₂) 0 ∧
    deriv (position p) 0 = pack 0 (periSpeed p) ∧
    deriv (position p) p.transferTime = pack 0 (-apoSpeed p) ∧
    incoming p 0 = position p 0 ∧
    position p p.transferTime = outgoing p p.transferTime ∧
    (∀ t, deriv (deriv (incoming p)) t =
      -(p.mu/‖incoming p t‖^3) • incoming p t) ∧
    (∀ t, deriv (deriv (outgoing p)) t =
      -(p.mu/‖outgoing p t‖^3) • outgoing p t) ∧
    ‖deriv (position p) 0-deriv (incoming p) 0‖ = deltaV₁ p ∧
    ‖deriv (outgoing p) p.transferTime-deriv (position p) p.transferTime‖ = deltaV₂ p ∧
    0 < deltaV₁ p ∧ 0 < deltaV₂ p ∧
    deltaV₁ p = Real.sqrt (p.mu/p.r₁)*(Real.sqrt (2*p.r₂/(p.r₁+p.r₂))-1) ∧
    deltaV₂ p = Real.sqrt (p.mu/p.r₂)*(1-Real.sqrt (2*p.r₁/(p.r₁+p.r₂))) ∧
    p.transferTime = Real.pi*Real.sqrt (p.a^3/p.mu) ∧
    (∀ t, specificEnergy p.mu (position p t) (deriv (position p) t) = -p.mu/(2*p.a)) ∧
    (∀ t, cross (position p t) (deriv (position p) t) = p.a*p.b*p.n) := by
  refine ⟨p.transferTime_pos, second_deriv_position p, position_bounds p,
    position_departure p, position_arrival p, ?_, ?_,
    (junction_positions p).1, (junction_positions p).2,
    incoming_newton p, outgoing_newton p, ?_, ?_,
    deltaV₁_pos p, deltaV₂_pos p, deltaV₁_formula p, deltaV₂_formula p,
    p.transferTime_eq, coast_energy p, coast_angular_momentum p⟩
  · rw [deriv_position, velocity_departure]
  · rw [deriv_position, velocity_arrival]
  · rw [(junction_velocity_jumps p).1, entryImpulse_norm]
  · rw [(junction_velocity_jumps p).2, exitImpulse_norm]

/-- Existence without asking the reader to trust a project-defined orbit predicate.
All geometric and motion hypotheses are consequences, not input fields. -/
theorem exists_hohmann_transfer (mu r₁ r₂ : ℝ)
    (hmu : 0 < mu) (hr₁ : 0 < r₁) (horder : r₁ < r₂) :
    ∃ (q v c₁ c₂ : ℝ → ℂ) (τ d₁ d₂ : ℝ),
      0 < τ ∧ 0 < d₁ ∧ 0 < d₂ ∧
      (∀ t, HasDerivAt q (v t) t) ∧
      (∀ t, HasDerivAt v (-(mu/‖q t‖^3) • q t) t) ∧
      (∀ t, deriv (deriv q) t = -(mu/‖q t‖^3) • q t) ∧
      (∀ t, r₁ ≤ ‖q t‖ ∧ ‖q t‖ ≤ r₂) ∧
      q 0 = pack r₁ 0 ∧ q τ = pack (-r₂) 0 ∧
      (∀ t, ‖c₁ t‖ = r₁) ∧ (∀ t, ‖c₂ t‖ = r₂) ∧
      (∀ t, deriv (deriv c₁) t = -(mu/‖c₁ t‖^3) • c₁ t) ∧
      (∀ t, deriv (deriv c₂) t = -(mu/‖c₂ t‖^3) • c₂ t) ∧
      c₁ 0 = q 0 ∧ q τ = c₂ τ ∧
      v 0-deriv c₁ 0 = pack 0 d₁ ∧
      deriv c₂ τ-v τ = pack 0 (-d₂) ∧
      ‖v 0-deriv c₁ 0‖ = d₁ ∧ ‖deriv c₂ τ-v τ‖ = d₂ ∧
      d₁ = Real.sqrt (mu/r₁)*(Real.sqrt (2*r₂/(r₁+r₂))-1) ∧
      d₂ = Real.sqrt (mu/r₂)*(1-Real.sqrt (2*r₁/(r₁+r₂))) ∧
      τ = Real.pi*Real.sqrt (((r₁+r₂)/2)^3/mu) := by
  let p : Parameters := ⟨mu,r₁,r₂,hmu,hr₁,horder⟩
  refine ⟨position p,velocity p,incoming p,outgoing p,
    p.transferTime,deltaV₁ p,deltaV₂ p,p.transferTime_pos,
    deltaV₁_pos p,deltaV₂_pos p,hasDerivAt_position p,
    hasDerivAt_velocity_newton p,second_deriv_position p,position_bounds p,
    position_departure p,position_arrival p,incoming_radius p,outgoing_radius p,
    incoming_newton p,outgoing_newton p,
    (junction_positions p).1,(junction_positions p).2,?_,?_,?_,?_,
    deltaV₁_formula p,deltaV₂_formula p,p.transferTime_eq⟩
  · rw [incoming_velocity_zero]
    exact entryImpulse_eq p
  · rw [outgoing_velocity_arrival]
    exact exitImpulse_eq p
  · rw [incoming_velocity_zero]
    exact entryImpulse_norm p
  · rw [outgoing_velocity_arrival]
    exact exitImpulse_norm p

end HohmannTransfer
