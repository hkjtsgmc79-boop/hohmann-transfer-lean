import Mathlib
-- These probes must be compiled against the pinned checkout, not live docs.
#check strictMono_of_hasDerivAt_pos
#check mem_range_of_exists_le_of_exists_ge
#check Equiv.ofBijective
#check OrderIso.continuous
#check HasDerivAt.of_local_left_inverse
#check HasDerivAt.ofReal_comp
#check Complex.normSq_eq_norm_sq
#check Real.sin_sq_add_cos_sq
#check Real.sq_sqrt
#check Real.cos_add_two_pi
#check Real.sin_add_two_pi
