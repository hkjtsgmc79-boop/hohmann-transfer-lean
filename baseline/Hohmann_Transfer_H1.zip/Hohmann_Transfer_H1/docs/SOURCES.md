# Sources consulted 2026-11-13

The mathematical specification is an original derivation of a classical model.
References guide scope and API choice; they are not external proof oracles.

- NASA/JPL, Basics of Space Flight, Chapter 4: Trajectories.
  https://science.nasa.gov/learn/basics-of-space-flight/chapter4-1/
  Scope: tangential departure, elliptical coast, arrival geometry; arrival at an
  orbit is distinct from rendezvous with a moving target.
- Bryan Weber, Orbital Mechanics & Astrodynamics, Hohmann Transfer.
  https://orbital-mechanics.space/orbital-maneuvers/hohmann-transfer.html
  Scope: standard circular-to-circular Δv and half-ellipse transfer time.
- Mathlib documentation, inverse derivative.
  https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Calculus/Deriv/Inverse.html
- Mathlib documentation, positive derivative and strict monotonicity.
  https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Calculus/Deriv/MeanValue.html
- Mathlib documentation, monotone continuity / OrderIso.continuous.
  https://leanprover-community.github.io/mathlib4_docs/Mathlib/Topology/Order/MonotoneContinuity.html
- Mathlib documentation, intermediate value / range from upper and lower witnesses.
  https://leanprover-community.github.io/mathlib4_docs/Mathlib/Topology/Order/IntermediateValue.html

IMPORTANT: these documentation pages track a moving branch. The exact pinned
commit could not be fetched in the cloud environment. APIProbe and compilation
against the pinned checkout are the authority for compatibility, not these pages.
No exhaustive literature/prior-art audit or independent compilation was performed.
