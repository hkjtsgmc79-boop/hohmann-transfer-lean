"""Small tests of the handoff tools; explicitly NOT Lean theorem tests."""
import sys
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_support import strip_comments_strings,parse_axioms,inventory,generate_exports,MODULES,public_signatures

class Tools(unittest.TestCase):
    def test_nested_comment(self):
        s=strip_comments_strings('/- sorry /- axiom -/ admit -/ lemma t : True := by trivial')
        self.assertNotIn('sorry',s); self.assertIn('lemma',s)
    def test_string_ignored(self): self.assertNotIn('sorry',strip_comments_strings('#check "sorry"'))
    def test_bad_unterminated_comment(self):
        with self.assertRaises(ValueError): strip_comments_strings('/- no end')
    def test_bypass_visible(self): self.assertIn('sorry',strip_comments_strings('by sorry'))
    def test_standard_axioms(self):
        self.assertTrue(parse_axioms("'T' depends on axioms: [propext,\n Classical.choice, Quot.sound]",['T'])['passed'])
    def test_empty_axioms(self):
        self.assertTrue(parse_axioms("'T' does not depend on any axioms",['T'])['passed'])
    def test_missing_rejected(self): self.assertFalse(parse_axioms('', ['T'])['passed'])
    def test_sorry_rejected(self):
        self.assertFalse(parse_axioms("'T' depends on axioms: [sorryAx]",['T'])['passed'])
    def test_invented_axiom_rejected(self):
        self.assertFalse(parse_axioms("'T' depends on axioms: [HohmannTransfer.assumePhysics]",['T'])['passed'])
    def test_extra_name_rejected(self):
        self.assertFalse(parse_axioms("'T' depends on axioms: []\n'X' depends on axioms: []",['T'])['passed'])
    def test_inventory(self):
        inv=inventory(ROOT); self.assertEqual(inv['modules'],12); self.assertEqual(inv['forbidden_tokens'],[])
    def test_single_file_has_no_project_import(self):
        generate_exports(ROOT)
        text=(ROOT/'Hohmann_Transfer_H1_All.lean').read_text()
        self.assertNotIn('import HohmannTransfer',text)
        self.assertEqual(text.count('-- SOURCE MODULE:'),len(MODULES))

    def test_public_contract_matches(self):
        frozen=(ROOT/'contracts/PublicStatement_H1.lean.txt').read_text()
        live=(ROOT/'HohmannTransfer/PublicStatement.lean').read_text()
        self.assertEqual(public_signatures(frozen),public_signatures(live))
    def test_changed_hypothesis_detected(self):
        a='theorem T (h : 0 < r) : r != 0 := by exact ne_of_gt h'
        b='theorem T (h : 1 < r) : r != 0 := by omega'
        self.assertNotEqual(public_signatures(a),public_signatures(b))
    def test_dependency_order(self):
        seen=set()
        for name in MODULES:
            text=(ROOT/'HohmannTransfer'/f'{name}.lean').read_text()
            import re
            for dep in re.findall(r'^import HohmannTransfer\.(\w+)$',text,re.M):
                self.assertIn(dep,seen)
            seen.add(name)

if __name__=='__main__': unittest.main()
