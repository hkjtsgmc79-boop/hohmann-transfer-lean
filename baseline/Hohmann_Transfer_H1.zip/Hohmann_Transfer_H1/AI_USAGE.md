# AI contribution and responsibility

H1 mathematics, Lean candidate scripts, support code and documentation were
prepared with an OpenAI assistant at the user's direction for Chengyuan AI Lab.
No human line-by-line scientific review or Lean kernel pass is claimed here.
The prior Z1 handoff tooling was adapted; H1 is a separate namespace and project.
A human submitting upstream remains responsible for theorem meaning, code,
references, licensing, and responding to review. No upstream submission has occurred.
