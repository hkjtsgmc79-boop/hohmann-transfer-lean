import HohmannTransfer

#print axioms HohmannTransfer.Parameters.transferTime_eq
#print axioms HohmannTransfer.clock_surjective
#print axioms HohmannTransfer.hasDerivAt_anomaly
#print axioms HohmannTransfer.hasDerivAt_position
#print axioms HohmannTransfer.hasDerivAt_velocity_newton
#print axioms HohmannTransfer.second_deriv_position
#print axioms HohmannTransfer.circular_newton
#print axioms HohmannTransfer.periSpeed_formula
#print axioms HohmannTransfer.apoSpeed_formula
#print axioms HohmannTransfer.deltaV₁_formula
#print axioms HohmannTransfer.deltaV₂_formula
#print axioms HohmannTransfer.junction_velocity_jumps
#print axioms HohmannTransfer.coast_energy
#print axioms HohmannTransfer.coast_angular_momentum
#print axioms HohmannTransfer.hohmann_transfer
#print axioms HohmannTransfer.exists_hohmann_transfer
