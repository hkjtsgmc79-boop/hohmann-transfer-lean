import HohmannTransfer
noncomputable section
open HohmannTransfer

-- Nontrivial radius ratio, not a circular or zero-impulse degeneracy.
def unitExample : Parameters where
  mu := 1
  r₁ := 1
  r₂ := 2
  mu_pos := by norm_num
  r₁_pos := by norm_num
  outward := by norm_num

example : 0 < deltaV₁ unitExample := deltaV₁_pos _
example : 0 < deltaV₂ unitExample := deltaV₂_pos _
example (t : ℝ) :
    deriv (deriv (position unitExample)) t =
      -(1/‖position unitExample t‖^3) • position unitExample t :=
  second_deriv_position _ _
example : (Parameters.a unitExample) = 3/2 := by
  norm_num [Parameters.a, unitExample]
example : (Parameters.e unitExample) = 1/3 := by
  norm_num [Parameters.e, unitExample]
example : unitExample.transferTime = Real.pi * Real.sqrt ((3/2:ℝ)^3) := by
  simpa [unitExample, Parameters.a] using unitExample.transferTime_eq

-- Arbitrary physical inputs remain universally quantified in the main theorem.
#check HohmannTransfer.exists_hohmann_transfer
