#!/usr/bin/env python3
import json
from pathlib import Path
from build_support import generate_exports, inventory
root=Path(__file__).resolve().parents[1]
generate_exports(root)
(root/'reports/source-inventory.json').write_text(json.dumps(inventory(root),indent=2)+'\n')
print('Regenerated single-file source and text export; this is NOT a Lean validation.')
