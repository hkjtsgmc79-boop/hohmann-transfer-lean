#!/usr/bin/env python3
"""Compile H1 using an existing fixed Lean+Mathlib installation, then audit axioms.

No downloads, lake update, installation or modifications to the shared cache.
Source packages and logs are returned even when compilation is blocked/fails.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import zipfile
from build_support import MODULES, generate_exports, inventory, parse_axioms, sha256, public_signatures

ROOT=Path(__file__).resolve().parents[1]
PIN='c5ea00351c28e24afc9f0f84379aa41082b1188f'


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean',default=os.environ.get('LEAN_BIN'))
    parser.add_argument('--mathlib-root',default=os.environ.get('MATHLIB_ROOT'))
    parser.add_argument('--timeout',type=int,default=600)
    args=parser.parse_args()
    runid=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=ROOT/'reports'/f'run_{runid}'; out.mkdir(parents=True)
    build=ROOT/'.build-local'/runid; build.mkdir(parents=True)
    report={'run_id':runid,'status':'BLOCKED','lean_verified':False,'commands':[],
            'started_utc':datetime.now(timezone.utc).isoformat(),'expected_mathlib':PIN,
            'note':'PASS requires all source builds, Examples, single file and 16 axiom reports.'}
    env=os.environ.copy()
    def command(tag,cmd,environment=None):
        start=time.monotonic()
        try:
            r=subprocess.run(cmd,cwd=ROOT,env=environment or env,text=True,
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=args.timeout)
            code=r.returncode; text=r.stdout
        except subprocess.TimeoutExpired as e:
            code=124
            raw=e.stdout or ''
            text=(raw.decode(errors='replace') if isinstance(raw,bytes) else raw)+'\nTIMEOUT\n'
        except OSError as e:
            code=127; text=str(e)+'\n'
        (out/f'{tag}.log').write_text(text)
        rec={'tag':tag,'argv':cmd,'exit_code':code,'seconds':time.monotonic()-start,
             'log':f'{tag}.log','log_sha256':sha256(out/f'{tag}.log')}
        report['commands'].append(rec)
        print(f'{tag}: exit={code}',flush=True)
        return code,text
    try:
        generate_exports(ROOT)
        inv=inventory(ROOT); (out/'source-inventory.json').write_text(json.dumps(inv,indent=2))
        report['source_hashes']={str(p.relative_to(ROOT)):sha256(p)
            for p in ROOT.rglob('*.lean') if '.build-local' not in p.parts and '.lake' not in p.parts}
        if inv['forbidden_tokens']:
            raise RuntimeError('FAIL: proof-bypass keywords found in source inventory.')
        frozen=public_signatures((ROOT/'contracts/PublicStatement_H1.lean.txt').read_text())
        live=public_signatures((ROOT/'HohmannTransfer/PublicStatement.lean').read_text())
        if frozen != live:
            raise RuntimeError('FAIL: Public theorem signatures differ from the H1 contract. Keep the original statement; proof bodies may be repaired.')
        lean=args.lean or shutil.which('lean')
        if not lean:
            raise RuntimeError('BLOCKED: Lean executable not found. Supply --lean or LEAN_BIN; no compilation ran.')
        lean=str(Path(lean).expanduser().resolve())
        code,text=command('lean-version',[lean,'--version'])
        if code or not re.search(r'\bversion\s+4\.30\.0(?:\s|,|\))',text):
            raise RuntimeError('BLOCKED: expected Lean 4.30.0; keep other toolchains separate.')
        mathroot=Path(args.mathlib_root).expanduser().resolve() if args.mathlib_root else ROOT/'.lake/packages/mathlib'
        if not (mathroot/'.lake/build/lib/lean').is_dir():
            raise RuntimeError('BLOCKED: Mathlib compiled cache missing; supply --mathlib-root. No cache update was attempted.')
        code,text=command('mathlib-commit',['git','-C',str(mathroot),'rev-parse','HEAD'])
        if code or text.strip()!=PIN:
            raise RuntimeError('BLOCKED: Mathlib checkout does not match the pinned commit.')
        code, dirty=command('mathlib-status',['git','-C',str(mathroot),'status','--porcelain','--untracked-files=no'])
        if code or dirty.strip():
            raise RuntimeError('BLOCKED: Mathlib has tracked local changes; use a clean pinned checkout/cache.')
        paths=[build,mathroot/'.lake/build/lib/lean']
        paths+=sorted((mathroot/'.lake/packages').glob('*/.lake/build/lib/lean'))
        env['LEAN_PATH']=os.pathsep.join(str(x) for x in paths)
        report['mathlib_root']=str(mathroot); report['lean_path']=env['LEAN_PATH']
        # The project's output directory is new and empty for every run.
        sequence=[('ApiProbe',ROOT/'ApiProbe.lean')]
        sequence += [(n,ROOT/'HohmannTransfer'/f'{n}.lean') for n in MODULES]
        sequence += [('root',ROOT/'HohmannTransfer.lean'),('examples',ROOT/'Examples.lean'),
                     ('single-file',ROOT/'Hohmann_Transfer_H1_All.lean'),('axioms',ROOT/'Audit.lean')]
        for tag,src in sequence:
            rel=src.relative_to(ROOT); dest=build/rel.with_suffix('.olean'); dest.parent.mkdir(parents=True,exist_ok=True)
            cmd=[lean,'-o',str(dest),'-i',str(dest.with_suffix('.ilean')),str(rel)]
            code,text=command(tag,cmd,env)
            if code or re.search(r"declaration uses ['`]?sorry|\bsorryAx\b",text):
                report['failed_stage']=tag
                raise RuntimeError(f'FAIL: {tag}; preserve its log and repair proof without weakening theorem.')
            if tag=='axioms':
                expected=re.findall(r'^#print axioms (\S+)',(ROOT/'Audit.lean').read_text(),re.M)
                audit=parse_axioms(text,expected)
                (out/'axiom-summary.json').write_text(json.dumps(audit,indent=2))
                if not audit['passed']: raise RuntimeError('FAIL: missing or nonstandard axiom dependencies.')
        report['status']='PASS'; report['lean_verified']=True
    except (RuntimeError,ValueError) as exc:
        msg=str(exc); report['reason']=msg
        report['status']='FAIL' if msg.startswith('FAIL:') else 'BLOCKED'
        print(msg,flush=True)
    except Exception as exc:
        report['status']='FAIL'; report['reason']=f'Runner exception {type(exc).__name__}: {exc}'
        print(report['reason'],flush=True)
    finally:
        report['finished_utc']=datetime.now(timezone.utc).isoformat()
        report['source_hashes_after']={str(p.relative_to(ROOT)):sha256(p)
            for p in ROOT.rglob('*.lean') if '.build-local' not in p.parts and '.lake' not in p.parts}
        if report.get('source_hashes')!=report['source_hashes_after']:
            report['status']='FAIL'; report['lean_verified']=False; report['reason']='Source changed during verification run.'
        (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
        package=ROOT/'reports'/f'Hohmann_Transfer_H1_return_{runid}.zip'
        with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob('*'):
                if not p.is_file() or any(x in p.parts for x in ['.lake','.build-local','__pycache__','.git']): continue
                if 'reports' in p.relative_to(ROOT).parts: continue
                z.write(p,'project/'+str(p.relative_to(ROOT)))
            for p in out.iterdir():
                if p.is_file(): z.write(p,'verification/'+p.name)
        print(f'RESULT: {report["status"]}\nReturn package: {package}',flush=True)
    return {'PASS':0,'FAIL':1,'BLOCKED':2}[report['status']]

if __name__=='__main__': sys.exit(main())
