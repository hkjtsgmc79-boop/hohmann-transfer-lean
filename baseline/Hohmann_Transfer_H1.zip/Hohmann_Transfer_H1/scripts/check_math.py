#!/usr/bin/env python3
"""Independent mathematical smoke tests. NOT Lean typechecking or a formal proof.

Requires numpy, scipy and sympy. All generated numeric cases are synthetic.
The ODE integrator uses the central gravity equation, independently of the
inverse-Kepler trajectory evaluator used for comparison.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

ROOT=Path(__file__).resolve().parents[1]

def main() -> int:
    symbolic=[]
    def exact(label,expr):
        result=s.factor(s.trigsimp(s.simplify(expr)))
        if result!=0: raise AssertionError(f'{label}: residual {result}')
        symbolic.append({'name':label,'residual':'0','passed':True})
    a,e,n,mu,r1,r2=s.symbols('a e n mu r1 r2', positive=True)
    u=s.symbols('u',real=True)
    b=s.sqrt(1-e**2)*a
    D=1-e*s.cos(u)
    x=a*(s.cos(u)-e); y=b*s.sin(u)
    K=(u-e*s.sin(u))/n
    vx=s.diff(x,u)*n/D; vy=s.diff(y,u)*n/D
    ax=s.diff(vx,u)*n/D; ay=s.diff(vy,u)*n/D
    exact('clock derivative',s.diff(K,u)-D/n)
    exact('radius squared from focus',x*x+y*y-(a*D)**2)
    exact('x velocity',vx+a*n*s.sin(u)/D)
    exact('y velocity',vy-b*n*s.cos(u)/D)
    exact('x acceleration',ax+a*n*n*(s.cos(u)-e)/D**3)
    exact('y acceleration',ay+b*n*n*s.sin(u)/D**3)
    exact('Newton x after n^2=mu/a^3',(ax+mu*x/(a*D)**3).subs(n*n,mu/a**3))
    exact('Newton y after n^2=mu/a^3',(ay+mu*y/(a*D)**3).subs(n*n,mu/a**3))
    exact('specific angular momentum',x*vy-y*vx-a*b*n)
    exact('vis-viva',(vx*vx+vy*vy).subs(n*n,mu/a**3)-mu*(2/(a*D)-1/a))
    exact('specific energy',((vx*vx+vy*vy)/2).subs(n*n,mu/a**3)-mu/(a*D)+mu/(2*a))
    A=(r1+r2)/2; E=(r2-r1)/(r1+r2)
    exact('periapsis radius',A*(1-E)-r1)
    exact('apoapsis radius',A*(1+E)-r2)
    exact('semiminor axis squared',A*A*(1-E*E)-r1*r2)
    vp2=(b*n/(1-e))**2
    va2=(b*n/(1+e))**2
    exact('periapsis speed squared',vp2.subs(n*n,mu/a**3).subs({a:A,e:E})-2*mu*r2/(r1*(r1+r2)))
    exact('apoapsis speed squared',va2.subs(n*n,mu/a**3).subs({a:A,e:E})-2*mu*r1/(r2*(r1+r2)))
    exact('first burn positivity numerator',2*mu*r2/(r1*(r1+r2))-mu/r1-mu*(r2-r1)/(r1*(r1+r2)))
    exact('second burn positivity numerator',mu/r2-2*mu*r1/(r2*(r1+r2))-mu*(r2-r1)/(r2*(r1+r2)))
    exact('departure position x',x.subs(u,0)-a*(1-e))
    exact('arrival position x',x.subs(u,s.pi)+a*(1+e))
    exact('departure velocity y',vy.subs(u,0)-b*n/(1-e))
    exact('arrival velocity y',vy.subs(u,s.pi)+b*n/(1+e))
    exact('half-period from Kepler clock',K.subs(u,s.pi)-s.pi/n)
    exact('transfer-time square',((s.pi/n)**2*mu-s.pi**2*a**3).subs(mu,n*n*a**3))
    exact('clock period shift',K.subs(u,u+2*s.pi)-K-2*s.pi/n)

    def params(m,r,R):
        a=(r+R)/2; e=(R-r)/(R+r); b=math.sqrt(r*R); n=math.sqrt(m/a**3)
        return a,e,b,n,math.pi/n
    def state(m,r,R,t):
        a,e,b,n,tau=params(m,r,R)
        # bracketing follows directly from |e sin(E)| <= e.
        M=n*t
        U=brentq(lambda U:U-e*math.sin(U)-M,M-e-1e-12,M+e+1e-12,xtol=5e-15)
        C,S=math.cos(U),math.sin(U); d=1-e*C
        q=np.array([a*(C-e),b*S]); v=np.array([-a*n*S/d,b*n*C/d])
        return U,q,v
    rng=np.random.default_rng(20261113)
    maxima={'ode_position_scaled':0.,'ode_velocity_scaled':0.,'kepler_residual':0.,
            'newton_scaled':0.,'energy_scaled':0.,'momentum_scaled':0.,'impulse_scaled':0.}
    cases=[]
    for k in range(48):
        m=float(10**rng.uniform(-1,1)); r=float(10**rng.uniform(-.4,.6))
        ratio=[1.01,1.05,1.2,2.,4.,8.,12.,16.][k%8]; R=r*ratio
        a,e,b,n,tau=params(m,r,R); vp=b*n/(1-e); va=b*n/(1+e)
        c1=math.sqrt(m/r); c2=math.sqrt(m/R); d1=vp-c1; d2=c2-va
        assert d1>0 and d2>0
        times=np.linspace(0,tau,9)
        def rhs(t,Y):
            q=Y[:2]; radius=np.linalg.norm(q)
            return np.r_[Y[2:],-m*q/radius**3]
        sol=solve_ivp(rhs,(0,tau),[r,0,0,vp],method='DOP853',t_eval=times,rtol=1e-11,atol=1e-12)
        if not sol.success: raise AssertionError(sol.message)
        for j,t in enumerate(times):
            U,q,v=state(m,r,R,t); C,S=math.cos(U),math.sin(U); d=1-e*C; dd=e*S
            # Differentiate quotient velocities, then multiply by dU/dt.
            acc=np.array([(-a*n*C*d+a*n*S*dd)/d**2,
                          (-b*n*S*d-b*n*C*dd)/d**2])*n/d
            gravity=-m*q/np.linalg.norm(q)**3
            er=np.linalg.norm(acc-gravity)/(1+np.linalg.norm(gravity))
            ep=np.linalg.norm(sol.y[:2,j]-q)/(1+R)
            ev=np.linalg.norm(sol.y[2:,j]-v)/(1+c1)
            en=abs(np.dot(v,v)/2-m/np.linalg.norm(q)+m/(2*a))/(1+m/a)
            h=abs(q[0]*v[1]-q[1]*v[0]-a*b*n)/(1+a*b*n)
            ke=abs(U-e*S-n*t)
            for key,val in [('ode_position_scaled',ep),('ode_velocity_scaled',ev),('kepler_residual',ke),('newton_scaled',er),('energy_scaled',en),('momentum_scaled',h)]:
                maxima[key]=max(maxima[key],float(val))
            assert er<2e-10 and ep<2e-8 and ev<2e-8 and en<2e-10 and h<2e-10
            assert r-1e-10*(1+r)<=np.linalg.norm(q)<=R+1e-10*(1+R)
        first=np.array([0,vp])-np.array([0,c1]); second=np.array([0,-c2])-np.array([0,-va])
        assert np.linalg.norm(first-[0,d1])<1e-12*(1+c1)
        assert np.linalg.norm(second-[0,-d2])<1e-12*(1+c2)
        formula1=c1*(math.sqrt(2*R/(r+R))-1)
        formula2=c2*(1-math.sqrt(2*r/(r+R)))
        err=max(abs(d1-formula1),abs(d2-formula2))/(1+c1)
        maxima['impulse_scaled']=max(maxima['impulse_scaled'],err)
        assert err<1e-12
        cases.append({'mu':m,'r1':r,'r2':R,'ratio':ratio,'samples':9,'passed':True})
    m,r,R=1.,1.,2.; a,e,b,n,tau=params(m,r,R); U=math.pi/2
    C,S=math.cos(U),math.sin(U); q=np.array([a*(C-e),b*S]);
    gravity=-m*q/np.linalg.norm(q)**3
    failures={}
    failures['uniform_eccentric_anomaly_is_wrong']=float(np.linalg.norm(np.array([-a*n*n*C,-b*n*n*S])-gravity))
    failures['omitted_focus_offset_is_wrong']=float(np.linalg.norm(np.array([a*C,b*S]))-a*(1-e*C))
    failures['semiminor_equals_semimajor_is_wrong']=float(np.linalg.norm(np.array([a*(C-e),a*S]))-a*(1-e*C))
    vp=b*n/(1-e); va=b*n/(1+e); c2=math.sqrt(m/R); dv2=c2-va
    failures['second_burn_positive_y_is_wrong']=float(np.linalg.norm(np.array([0,-va])+[0,dv2]-[0,-c2]))
    _,qfull,_=state(m,r,R,2*tau)
    failures['using_full_period_misses_destination']=float(np.linalg.norm(qfull-[-R,0]))
    failures['inverse_square_scalar_is_wrong']=float(np.linalg.norm(-m*q/np.linalg.norm(q)**2-gravity))
    assert all(abs(v)>1e-4 for v in failures.values())
    # A dimensionless pedagogical example: no claim about a real mission.
    example={'mu':1,'r1':1,'r2':2,'delta_v1':vp-1.,'delta_v2':c2-va,'total_delta_v':vp-1+c2-va,'transfer_time':tau}
    out={'status':'PASS','not_a_lean_proof':True,'symbolic_count':len(symbolic),'symbolic':symbolic,
         'numeric_cases':len(cases),'time_points':9*len(cases),'independent_ode_integrations':len(cases),
         'max_scaled_errors':maxima,'cases':cases,'negative_controls':failures,
         'negative_control_count':len(failures),'dimensionless_example':example}
    (ROOT/'reports/math-smoke.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['cases','symbolic']},indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
